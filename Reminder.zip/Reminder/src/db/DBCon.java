package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

    public class DBCon {
        private static final String URL = "jdbc:mysql://localhost:3307/reminder";
        private static final String USER = "root";
        private static final String PASSWORD = "Samuela.e7777";

        private static Connection connection;

        private DBCon() {}
         
         public static Connection getConnection() throws SQLException {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
            return connection;
         }   // Private constructor to prevent instantiation
        }
    