package model;

import java.time.LocalDate;

public class Purchase {

    private int       id;
    private Customer  customer;
    private Product   product;
    private LocalDate purchaseDate;
    private int       serviceIntervalMonths;

    // Tanggal servis terakhir — diisi oleh ReminderEngine
    private LocalDate lastServiceDate;

    public Purchase(int id, Customer customer, Product product,
                    LocalDate purchaseDate, int serviceIntervalMonths) {
        this.id                    = id;
        this.customer              = customer;
        this.product               = product;
        this.purchaseDate          = purchaseDate;
        this.serviceIntervalMonths = serviceIntervalMonths;
    }

    public Purchase(Customer customer, Product product,
                    LocalDate purchaseDate, int serviceIntervalMonths) {
        this(0, customer, product, purchaseDate, serviceIntervalMonths);
    }

    // Hitung next service:
    // - Kalau sudah pernah servis → dari tanggal servis terakhir
    // - Kalau belum pernah servis → dari tanggal beli
    public LocalDate getNextServiceDate() {
        LocalDate baseDate = (lastServiceDate != null) ? lastServiceDate : purchaseDate;
        return baseDate.plusMonths(serviceIntervalMonths);
    }

    public boolean isDueSoon(int daysAhead) {
        LocalDate today   = LocalDate.now();
        LocalDate dueDate = getNextServiceDate();
        return !dueDate.isBefore(today) && !dueDate.isAfter(today.plusDays(daysAhead));
    }

    // Dipanggil oleh ReminderEngine untuk set tanggal servis terakhir
    public void setLastServiceDate(LocalDate date) {
        this.lastServiceDate = date;
    }

    public LocalDate getLastServiceDate()       { return lastServiceDate; }
    public int       getId()                    { return id; }
    public Customer  getCustomer()              { return customer; }
    public Product   getProduct()               { return product; }
    public LocalDate getPurchaseDate()          { return purchaseDate; }
    public int       getServiceIntervalMonths() { return serviceIntervalMonths; }
}