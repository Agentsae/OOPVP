package model;

public class Product {

    private int    id;
    private String productName;

    // Constructor lengkap — dipakai saat load dari database
    public Product(int id, String productName) {
        this.id          = id;
        this.productName = productName;
    }

    // Constructor tanpa id — dipakai saat buat product baru
    public Product(String productName) {
        this(0, productName);
    }

    public int    getId()          { return id; }
    public String getProductName() { return productName; }
}