package model;

public class Customer {

    private int    id;
    private String name;
    private String phone;
    private String email;

    // Constructor lengkap — dipakai saat load dari database
    public Customer(int id, String name, String phone, String email) {
        this.id    = id;
        this.name  = name;
        this.phone = phone;
        this.email = email;
    }

    // Constructor tanpa id — dipakai saat buat customer baru
    public Customer(String name, String phone, String email) {
        this(0, name, phone, email);
    }

    public int    getId()    { return id; }
    public String getName()  { return name; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
}