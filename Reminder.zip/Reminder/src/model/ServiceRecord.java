package model;

import java.time.LocalDate;

public class ServiceRecord {

    private int       id;
    private int       purchaseId;
    private LocalDate serviceDate;
    private String    notes;

    public ServiceRecord(int id, int purchaseId, LocalDate serviceDate, String notes) {
        this.id          = id;
        this.purchaseId  = purchaseId;
        this.serviceDate = serviceDate;
        this.notes       = notes;
    }

    // Constructor tanpa id — untuk record baru
    public ServiceRecord(int purchaseId, LocalDate serviceDate, String notes) {
        this(0, purchaseId, serviceDate, notes);
    }

    public int       getId()          { return id; }
    public int       getPurchaseId()  { return purchaseId; }
    public LocalDate getServiceDate() { return serviceDate; }
    public String    getNotes()       { return notes; }
}