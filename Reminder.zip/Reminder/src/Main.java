import engine.ReminderScheduler;
import ui.MainWindow;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        System.out.println("Starting Service Reminder App...");

        // Buka window dulu
        SwingUtilities.invokeLater(() -> {
            MainWindow window = new MainWindow();
            window.setVisible(true);
        });

        // Tunggu sebentar supaya window sudah terbuka, baru cek reminder
        try { Thread.sleep(1000); } catch (InterruptedException e) {}

        // Langsung cek reminder saat app dibuka
        ReminderScheduler.runNow();
    }
}