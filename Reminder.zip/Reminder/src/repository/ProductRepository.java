package repository;

import db.DBCon;
import model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ProductRepository {

    public int save (Product product) throws SQLException {
        String query = "INSERT INTO products (product_name) VALUES (?)";
        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, product.getProductName());
            stmt.executeUpdate();

            ResultSet keys = stmt.getGeneratedKeys();
                if (keys.next()) return keys.getInt(1);
                return -1;
            }

    public List<Product> findAll() throws SQLException {
        List<Product> list = new ArrayList<>();
        String query = "SELECT id, product_name FROM products";
        Connection conn = DBCon.getConnection();
             ResultSet rs = conn.createStatement().executeQuery(query);
            while (rs.next()) {
                list.add(new Product(
                        rs.getInt("id"),
                        rs.getString("product_name")
                ));
            }
        return list;
    }

    public void update(int id, String productName) throws SQLException {
        String sql = "UPDATE products SET product_name=? WHERE id=?";
        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, productName);
            stmt.setInt(2, id);
            stmt.executeUpdate();
        }
    
}
