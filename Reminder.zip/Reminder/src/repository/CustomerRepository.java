package repository;

import db.DBCon;
import model.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CustomerRepository {

    public int save(Customer customer) throws SQLException {
        String sql = "INSERT INTO customers (name, phone, email) VALUES (?, ?, ?)";

        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, customer.getName());
        stmt.setString(2, customer.getPhone());
        stmt.setString(3, customer.getEmail());
        stmt.executeUpdate();

        ResultSet keys = stmt.getGeneratedKeys();
        if (keys.next()) return keys.getInt(1);
        return -1;
    }

    public List<Customer> findAll() throws SQLException {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT id, name, phone, email FROM customers";

        Connection conn = DBCon.getConnection();
        ResultSet rs = conn.createStatement().executeQuery(sql);

        while (rs.next()) {
            list.add(new Customer(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("phone"),
                rs.getString("email")
            ));
        }
        return list;
    }

    public void update(int id, String name, String phone, String email) throws SQLException {
        String sql = "UPDATE customers SET name=?, phone=?, email=? WHERE id=?";
        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, phone);
            stmt.setString(3, email);
            stmt.setInt(4, id);
            stmt.executeUpdate();
        }
}