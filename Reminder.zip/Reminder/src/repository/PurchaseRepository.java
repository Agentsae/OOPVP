package repository;

import db.DBCon;
import model.Customer;
import model.Product;
import model.Purchase;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PurchaseRepository {

    public void save(Purchase purchase) throws SQLException {
        String sql = "INSERT INTO purchases (customer_id, product_id, purchase_date, service_interval_months) VALUES (?, ?, ?, ?)";

        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, purchase.getCustomer().getId());
        stmt.setInt(2, purchase.getProduct().getId());
        stmt.setDate(3, Date.valueOf(purchase.getPurchaseDate()));
        stmt.setInt(4, purchase.getServiceIntervalMonths());
        stmt.executeUpdate();
    }

    public List<Purchase> findAll() throws SQLException {
        List<Purchase> list = new ArrayList<>();

        String sql = "SELECT p.id, p.purchase_date, p.service_interval_months, "
                   + "c.id, c.name, c.phone, c.email, "
                   + "pr.id, pr.product_name "
                   + "FROM purchases p "
                   + "JOIN customers c  ON p.customer_id = c.id "
                   + "JOIN products  pr ON p.product_id  = pr.id";

        Connection conn = DBCon.getConnection();
        ResultSet rs = conn.createStatement().executeQuery(sql);

        while (rs.next()) {
            Customer customer = new Customer(
                rs.getInt(4),
                rs.getString(5),
                rs.getString(6),
                rs.getString(7)
            );
            Product product = new Product(
                rs.getInt(8),
                rs.getString(9)
            );
            Purchase purchase = new Purchase(
                rs.getInt(1),
                customer,
                product,
                rs.getDate(2).toLocalDate(),
                rs.getInt(3)
            );
            list.add(purchase);
        }
        return list;
    }

    public void update(int id, LocalDate purchaseDate, int serviceIntervalMonths) throws SQLException {
        String sql = "UPDATE purchases SET purchase_date=?, service_interval_months=? WHERE id=?";
        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setDate(1, Date.valueOf(purchaseDate));
        stmt.setInt(2, serviceIntervalMonths);
        stmt.setInt(3, id);
        stmt.executeUpdate();
    }

    public void delete(int id) throws SQLException {
        // Hapus service_records dulu karena ada foreign key
        String deleteLogs    = "DELETE FROM service_records WHERE purchase_id=?";
        String deletePurchase = "DELETE FROM purchases WHERE id=?";

        Connection conn = DBCon.getConnection();

        PreparedStatement stmt1 = conn.prepareStatement(deleteLogs);
        stmt1.setInt(1, id);
        stmt1.executeUpdate();

        PreparedStatement stmt2 = conn.prepareStatement(deletePurchase);
        stmt2.setInt(1, id);
        stmt2.executeUpdate();
    }
}