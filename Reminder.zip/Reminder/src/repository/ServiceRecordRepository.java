package repository;

import db.DBCon;
import model.ServiceRecord;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class ServiceRecordRepository {

    // Simpan record servis baru
    public void save(ServiceRecord record) throws SQLException {
        System.out.println("[ServiceRecord] Menyimpan:");
        System.out.println("  Purchase_id  = " + record.getPurchaseId());
        System.out.println("  Service_date = " + record.getServiceDate());
        System.out.println("  Notes        = " + record.getNotes());

        String sql = "INSERT INTO service_records (Purchase_id, Service_date, Notes) VALUES (?, ?, ?)";

        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, record.getPurchaseId());
        stmt.setDate(2, Date.valueOf(record.getServiceDate()));
        stmt.setString(3, record.getNotes());
        stmt.executeUpdate();
    }

    // Ambil tanggal servis TERAKHIR untuk purchase tertentu
    // Kalau belum pernah servis, return null
    public LocalDate getLastServiceDate(int purchaseId) throws SQLException {
        String sql = "SELECT Service_date FROM service_records "
                   + "WHERE Purchase_id = ? "
                   + "ORDER BY Service_date DESC LIMIT 1";

        Connection conn = DBCon.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, purchaseId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return rs.getDate("Service_date").toLocalDate();
        }
        return null; // belum pernah servis
    }
}