package ui;

import engine.ReminderScheduler;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

public class MainWindow extends JFrame {

    public MainWindow() {
        setTitle("Service Reminder - Admin Panel");
        setSize(480, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ── Root panel ──
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(new Color(245, 247, 250));
        setContentPane(root);

        // ── Title ──
        JLabel title = new JLabel("Service Reminder System", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(40, 60, 100));
        title.setBorder(new EmptyBorder(30, 0, 4, 0));
        root.add(title, BorderLayout.NORTH);

        // ── Center panel with buttons ──
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(new Color(245, 247, 250));
        centerPanel.setBorder(new EmptyBorder(20, 80, 20, 80));

        JLabel subtitle = new JLabel("Admin Panel");
        subtitle.setFont(new Font("Arial", Font.ITALIC, 13));
        subtitle.setForeground(Color.GRAY);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(subtitle);
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(makeButton("Add New Purchase",     new Color(52, 120, 200)));
        centerPanel.add(Box.createVerticalStrut(12));
        centerPanel.add(makeButton("View Purchase History", new Color(80, 160, 100)));
        centerPanel.add(Box.createVerticalStrut(12));
        centerPanel.add(makeButton("Check Reminders Now",  new Color(200, 120, 40)));

        root.add(centerPanel, BorderLayout.CENTER);

        // ── Status bar ──
        JLabel status = new JLabel("  Scheduler running - checking every 24 hours");
        status.setFont(new Font("Arial", Font.PLAIN, 11));
        status.setForeground(new Color(100, 160, 100));
        status.setBorder(new EmptyBorder(8, 12, 8, 12));
        root.add(status, BorderLayout.SOUTH);
    }

    private JButton makeButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Wire actions
        if (text.contains("Add")) {
            btn.addActionListener(e -> new PurchaseFormDialog(this).setVisible(true));

        } else if (text.contains("View")) {
            btn.addActionListener(e -> new PurchaseHistoryDialog(this).setVisible(true));

        } else if (text.contains("Check")) {
            btn.addActionListener(e -> {
                ReminderScheduler.runNow();
                JOptionPane.showMessageDialog(this,
                    "Reminder check complete!\nCheck console for results.",
                    "Done", JOptionPane.INFORMATION_MESSAGE);
            });
        }

        return btn;
    }
}