package ui;

import model.Customer;
import model.Product;
import model.Purchase;
import repository.CustomerRepository;
import repository.ProductRepository;
import repository.PurchaseRepository;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class PurchaseFormDialog extends JDialog {

    private JTextField customerNameField;
    private JTextField customerPhoneField;
    private JTextField customerEmailField;
    private JTextField productNameField;
    private JTextField intervalField;
    private JTextField purchaseDateField;

    public PurchaseFormDialog(Frame parent) {
        super(parent, "Add New Purchase", true);
        setSize(420, 400);
        setLocationRelativeTo(parent);
        setResizable(false);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(0, 12));
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(20, 24, 16, 24));

        JLabel hint = new JLabel("* = wajib diisi   |   Format tanggal: YYYY-MM-DD");
        hint.setFont(new Font("Arial", Font.ITALIC, 11));
        hint.setForeground(Color.GRAY);
        root.add(hint, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(6, 2, 8, 10));
        form.setBackground(Color.WHITE);

        form.add(makeLabel("Nama Customer *"));
        customerNameField = new JTextField();
        form.add(customerNameField);

        form.add(makeLabel("No. HP (628xxx) *"));
        customerPhoneField = new JTextField();
        form.add(customerPhoneField);

        form.add(makeLabel("Email"));
        customerEmailField = new JTextField();
        form.add(customerEmailField);

        form.add(makeLabel("Nama Produk *"));
        productNameField = new JTextField();
        form.add(productNameField);

        form.add(makeLabel("Tanggal Pembelian *"));
        purchaseDateField = new JTextField(LocalDate.now().toString());
        form.add(purchaseDateField);

        form.add(makeLabel("Interval Servis (bulan) *"));
        intervalField = new JTextField();
        form.add(intervalField);

        root.add(form, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Color.WHITE);

        JButton cancelBtn = new JButton("Batal");
        cancelBtn.setFont(new Font("Arial", Font.PLAIN, 13));
        cancelBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        cancelBtn.addActionListener(e -> dispose());

        JButton saveBtn = new JButton("Simpan");
        saveBtn.setFont(new Font("Arial", Font.BOLD, 13));
        saveBtn.setBackground(new Color(52, 120, 200));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFocusPainted(false);
        saveBtn.setBorderPainted(false);
        saveBtn.setOpaque(true);
        saveBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        saveBtn.addActionListener(e -> handleSave());

        btnRow.add(cancelBtn);
        btnRow.add(saveBtn);
        root.add(btnRow, BorderLayout.SOUTH);

        setContentPane(root);
    }

    private JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 13));
        return label;
    }

    private void handleSave() {
        String name    = customerNameField.getText().trim();
        String phone   = customerPhoneField.getText().trim();
        String email   = customerEmailField.getText().trim();
        String product = productNameField.getText().trim();
        String dateStr = purchaseDateField.getText().trim();
        String intStr  = intervalField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || product.isEmpty()
                || dateStr.isEmpty() || intStr.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Mohon isi semua field yang wajib (*)",
                "Field Kosong", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int interval;
        try {
            interval = Integer.parseInt(intStr);
            if (interval <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Interval servis harus berupa angka positif (contoh: 6)",
                "Input Tidak Valid", JOptionPane.ERROR_MESSAGE);
            return;
        }

        LocalDate date;
        try {
            date = LocalDate.parse(dateStr);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this,
                "Format tanggal harus YYYY-MM-DD (contoh: 2025-01-15)",
                "Tanggal Tidak Valid", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            CustomerRepository customerRepo = new CustomerRepository();
            Customer customer = new Customer(name, phone, email);
            int customerId = customerRepo.save(customer);
            Customer savedCustomer = new Customer(customerId, name, phone, email);

            ProductRepository productRepo = new ProductRepository();
            Product prod = new Product(product);
            int productId = productRepo.save(prod);
            Product savedProduct = new Product(productId, product);

            PurchaseRepository purchaseRepo = new PurchaseRepository();
            Purchase purchase = new Purchase(
                0,
                savedCustomer,
                savedProduct,
                date,
                interval
            );
            purchaseRepo.save(purchase);

            JOptionPane.showMessageDialog(this,
                "Data berhasil disimpan!\n\n" +
                "Customer      : " + name                          + "\n" +
                "Produk        : " + product                       + "\n" +
                "Tanggal Beli  : " + date                          + "\n" +
                "Servis Berikut: " + purchase.getNextServiceDate() + "\n" +
                "Interval      : setiap " + interval + " bulan",
                "Berhasil!", JOptionPane.INFORMATION_MESSAGE);

            dispose();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Gagal menyimpan: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}