package ui;

import model.Customer;
import model.Product;
import model.Purchase;
import model.ServiceRecord;
import repository.CustomerRepository;
import repository.ProductRepository;
import repository.PurchaseRepository;
import repository.ServiceRecordRepository;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.DefaultCellEditor;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.util.List;

public class PurchaseHistoryDialog extends JDialog {

    private JTable table;
    private DefaultTableModel tableModel;
    private List<Purchase> purchases;

    public PurchaseHistoryDialog(Frame parent) {
        super(parent, "Purchase History", true);
        setSize(920, 440);
        setLocationRelativeTo(parent);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBorder(new EmptyBorder(16, 16, 12, 16));
        root.setBackground(Color.WHITE);

        // ── Header ──
        JLabel header = new JLabel("Riwayat Pembelian & Jadwal Servis");
        header.setFont(new Font("Arial", Font.BOLD, 15));
        header.setForeground(new Color(40, 60, 100));
        root.add(header, BorderLayout.NORTH);

        // ── Kolom tabel ──
        String[] columns = {
            "ID", "Customer", "No. HP", "Produk",
            "Tgl Beli", "Interval", "Servis Terakhir",
            "Next Service", "Servis", "Edit", "Hapus"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) {
                return c == 8 || c == 9 || c == 10; // hanya kolom aksi
            }
        };

        // ── Load data dari database ──
        loadData();

        // ── Setup tabel ──
        table = new JTable(tableModel);
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        table.setRowHeight(34);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        table.getTableHeader().setBackground(new Color(52, 120, 200));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setGridColor(new Color(220, 220, 220));
        table.setSelectionBackground(new Color(52, 120, 200, 40));

        // Sembunyikan kolom ID tapi tetap tersimpan datanya
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);

        // Set lebar kolom tombol
        table.getColumnModel().getColumn(8).setPreferredWidth(140);
        table.getColumnModel().getColumn(9).setPreferredWidth(80);
        table.getColumnModel().getColumn(10).setPreferredWidth(80);

        // Pasang renderer dan editor untuk kolom aksi
        table.getColumn("Servis").setCellRenderer(new ActionButtonRenderer(new Color(80, 160, 100)));
        table.getColumn("Servis").setCellEditor(new ActionButtonEditor(new JCheckBox(), this, "servis"));

        table.getColumn("Edit").setCellRenderer(new ActionButtonRenderer(new Color(52, 120, 200)));
        table.getColumn("Edit").setCellEditor(new ActionButtonEditor(new JCheckBox(), this, "edit"));

        table.getColumn("Hapus").setCellRenderer(new ActionButtonRenderer(new Color(200, 60, 60)));
        table.getColumn("Hapus").setCellEditor(new ActionButtonEditor(new JCheckBox(), this, "hapus"));

        JScrollPane scroll = new JScrollPane(table);
        root.add(scroll, BorderLayout.CENTER);

        // ── Tombol tutup ──
        JButton closeBtn = new JButton("Tutup");
        closeBtn.setFont(new Font("Arial", Font.PLAIN, 13));
        closeBtn.addActionListener(e -> dispose());

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnRow.setBackground(Color.WHITE);
        btnRow.add(closeBtn);
        root.add(btnRow, BorderLayout.SOUTH);

        setContentPane(root);
    }

    // ── Load / Reload data dari database ──
    private void loadData() {
        tableModel.setRowCount(0); // kosongkan tabel dulu

        try {
            PurchaseRepository repo         = new PurchaseRepository();
            ServiceRecordRepository svcRepo = new ServiceRecordRepository();
            purchases = repo.findAll();

            for (Purchase p : purchases) {
                LocalDate lastSvc = svcRepo.getLastServiceDate(p.getId());
                p.setLastServiceDate(lastSvc);

                tableModel.addRow(new Object[]{
                    p.getId(),
                    p.getCustomer().getName(),
                    p.getCustomer().getPhone(),
                    p.getProduct().getProductName(),
                    p.getPurchaseDate(),
                    p.getServiceIntervalMonths() + " bln",
                    lastSvc != null ? lastSvc.toString() : "Belum servis",
                    p.getNextServiceDate(),
                    "Tandai Servis",
                    "Edit",
                    "Hapus"
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Gagal memuat data: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ══════════════════════════════════════════════════════
    // AKSI: TANDAI SUDAH SERVIS
    // ══════════════════════════════════════════════════════
    public void markAsServiced(int row) {
        Purchase purchase = purchases.get(row);

        String dateStr = (String) JOptionPane.showInputDialog(
            this,
            "Masukkan tanggal servis:\n" +
            "Customer : " + purchase.getCustomer().getName() + "\n" +
            "Produk   : " + purchase.getProduct().getProductName() + "\n\n" +
            "Format   : YYYY-MM-DD",
            "Tandai Sudah Servis",
            JOptionPane.PLAIN_MESSAGE,
            null, null,
            LocalDate.now().toString()
        );

        if (dateStr == null || dateStr.trim().isEmpty()) return;

        LocalDate serviceDate;
        try {
            serviceDate = LocalDate.parse(dateStr.trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Format tanggal salah! Gunakan YYYY-MM-DD\nContoh: " + LocalDate.now(),
                "Format Salah", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (serviceDate.isAfter(LocalDate.now())) {
            JOptionPane.showMessageDialog(this,
                "Tanggal servis tidak boleh di masa depan!",
                "Tanggal Tidak Valid", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            ServiceRecordRepository repo = new ServiceRecordRepository();
            repo.save(new ServiceRecord(purchase.getId(), serviceDate, "Servis dilakukan"));

            JOptionPane.showMessageDialog(this,
                "Servis berhasil dicatat!\n\n" +
                "Customer      : " + purchase.getCustomer().getName() + "\n" +
                "Tanggal Servis: " + serviceDate + "\n" +
                "Next Service  : " + purchase.getNextServiceDate(),
                "Berhasil!", JOptionPane.INFORMATION_MESSAGE);

            loadData(); // refresh tabel

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Gagal menyimpan: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ══════════════════════════════════════════════════════
    // AKSI: EDIT DATA PURCHASE
    // ══════════════════════════════════════════════════════
    public void editPurchase(int row) {
        Purchase purchase = purchases.get(row);

        // Buat form edit
        JTextField nameField     = new JTextField(purchase.getCustomer().getName());
        JTextField phoneField    = new JTextField(purchase.getCustomer().getPhone());
        JTextField emailField    = new JTextField(purchase.getCustomer().getEmail());
        JTextField productField  = new JTextField(purchase.getProduct().getProductName());
        JTextField dateField     = new JTextField(purchase.getPurchaseDate().toString());
        JTextField intervalField = new JTextField(String.valueOf(purchase.getServiceIntervalMonths()));

        JPanel form = new JPanel(new GridLayout(6, 2, 8, 8));
        form.add(new JLabel("Nama Customer:"));   form.add(nameField);
        form.add(new JLabel("No. HP:"));          form.add(phoneField);
        form.add(new JLabel("Email:"));           form.add(emailField);
        form.add(new JLabel("Nama Produk:"));     form.add(productField);
        form.add(new JLabel("Tanggal Beli:"));    form.add(dateField);
        form.add(new JLabel("Interval (bulan):")); form.add(intervalField);

        int result = JOptionPane.showConfirmDialog(
            this, form,
            "Edit Purchase — " + purchase.getCustomer().getName(),
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result != JOptionPane.OK_OPTION) return;

        // Validasi input
        if (nameField.getText().trim().isEmpty() || phoneField.getText().trim().isEmpty()
                || productField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Nama, No. HP, dan Produk tidak boleh kosong!",
                "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int interval;
        try {
            interval = Integer.parseInt(intervalField.getText().trim());
            if (interval <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Interval harus berupa angka positif!",
                "Input Salah", JOptionPane.ERROR_MESSAGE);
            return;
        }

        LocalDate date;
        try {
            date = LocalDate.parse(dateField.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Format tanggal harus YYYY-MM-DD!",
                "Input Salah", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Simpan perubahan ke database
        try {
            CustomerRepository customerRepo = new CustomerRepository();
            customerRepo.update(
                purchase.getCustomer().getId(),
                nameField.getText().trim(),
                phoneField.getText().trim(),
                emailField.getText().trim()
            );

            ProductRepository productRepo = new ProductRepository();
            productRepo.update(
                purchase.getProduct().getId(),
                productField.getText().trim()
            );

            PurchaseRepository purchaseRepo = new PurchaseRepository();
            purchaseRepo.update(purchase.getId(), date, interval);

            JOptionPane.showMessageDialog(this,
                "Data berhasil diupdate!",
                "Berhasil!", JOptionPane.INFORMATION_MESSAGE);

            loadData(); // refresh tabel

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Gagal mengupdate: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // ══════════════════════════════════════════════════════
    // AKSI: HAPUS DATA PURCHASE
    // ══════════════════════════════════════════════════════
    public void deletePurchase(int row) {
        Purchase purchase = purchases.get(row);

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Yakin ingin menghapus data ini?\n\n" +
            "Customer : " + purchase.getCustomer().getName() + "\n" +
            "Produk   : " + purchase.getProduct().getProductName() + "\n" +
            "Tgl Beli : " + purchase.getPurchaseDate() + "\n\n" +
            "Data yang dihapus tidak bisa dikembalikan!",
            "Konfirmasi Hapus",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            PurchaseRepository repo = new PurchaseRepository();
            repo.delete(purchase.getId());

            JOptionPane.showMessageDialog(this,
                "Data berhasil dihapus!",
                "Dihapus", JOptionPane.INFORMATION_MESSAGE);

            loadData(); // refresh tabel

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Gagal menghapus: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // ══════════════════════════════════════════════════════
    // BUTTON RENDERER — untuk tampilkan tombol di tabel
    // ══════════════════════════════════════════════════════
    static class ActionButtonRenderer extends JButton implements TableCellRenderer {
        public ActionButtonRenderer(Color color) {
            setOpaque(true);
            setBackground(color);
            setForeground(Color.WHITE);
            setFont(new Font("Arial", Font.BOLD, 11));
            setBorderPainted(false);
            setFocusPainted(false);
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {
            setText(value != null ? value.toString() : "");
            return this;
        }
    }

    // ══════════════════════════════════════════════════════
    // BUTTON EDITOR — untuk handle klik tombol di tabel
    // ══════════════════════════════════════════════════════
    static class ActionButtonEditor extends DefaultCellEditor {
        private JButton button;
        private PurchaseHistoryDialog dialog;
        private String action;
        private int currentRow;

        public ActionButtonEditor(JCheckBox checkBox, PurchaseHistoryDialog dialog, String action) {
            super(checkBox);
            this.dialog = dialog;
            this.action = action;

            Color color = action.equals("servis") ? new Color(80, 160, 100)
                        : action.equals("edit")   ? new Color(52, 120, 200)
                        : new Color(200, 60, 60);

            button = new JButton();
            button.setOpaque(true);
            button.setBackground(color);
            button.setForeground(Color.WHITE);
            button.setFont(new Font("Arial", Font.BOLD, 11));
            button.setBorderPainted(false);
            button.setFocusPainted(false);

            button.addActionListener(e -> {
                fireEditingStopped();
                if      (action.equals("servis")) dialog.markAsServiced(currentRow);
                else if (action.equals("edit"))   dialog.editPurchase(currentRow);
                else if (action.equals("hapus"))  dialog.deletePurchase(currentRow);
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int col) {
            currentRow = row;
            button.setText(value != null ? value.toString() : "");
            return button;
        }

        public Object getCellEditorValue() { return button.getText(); }
    }
}