package notification;

import model.Customer;
import model.Product;

import java.net.URI;
import java.net.http.*;
import java.time.LocalDate;

public class WhatsAppNotification extends Notification {

    @Override
    public void send(Customer customer, Product product, LocalDate dueDate) {
        String waMessage = buildMessage(customer, product, dueDate);
        String wa_number = customer.getPhone();
        
        try {
            String body = "target=" + wa_number + "&waMessage=" + waMessage;
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.fonnte.com/send"))
                .header("Authorization"FONNTE_TOKEN)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
            
            HttpResponse<String> response = HttpClient.newHttpClient()
            .send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("WhatsApp message sent to " + customer.getName() + " (" + wa_number + ")" + 
                "| Response: " + response.body());
        } catch (Exception e) {
            System.err.println("Failed to send WhatsApp message to " + customer.getName() + " (" + wa_number + "): " 
            + e.getMessage());
        }

    }
}



