package notification;

import model.Customer;
import model.Product;

import java.time.LocalDate;


public abstract class Notification {

    public abstract void send(Customer customer, Product product, LocalDate dueDate);

    protected String buildMessage(Customer customer, Product product, LocalDate dueDate) {
        return "Dear " + customer.getName() + ", your " + product.getProductName() + " is due for service " + dueDate + ". Please contact us to schedule an appointment."  ;
    }
    
}
