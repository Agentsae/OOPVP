package notification;

import model.Customer;
import model.Product;

import javax.swing.JOptionPane;
import java.time.LocalDate;

 public class AdminAlertNotification extends Notification {

    @Override
    public void send(Customer customer, Product product, LocalDate dueDate) {
        String message = 
        "SERVICE REMINDER\n\n"+
        "Customer: " + customer.getName() + "\n" +
        "Product: " + product.getProductName() + "\n" +
        "Due Date: " + dueDate + "\n\n" +
        "Send WhatsApp message to this customer?";
        
        int choice = JOptionPane.showConfirmDialog(null, message, "Service Admin Alert", 
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);

        if (choice == JOptionPane.YES_OPTION) {
            String waMessage = buildMessage(customer, product, dueDate);
            // Simulate sending WhatsApp message
            JOptionPane.showMessageDialog(null, "WhatsApp message sent:\n\n" + 
                waMessage, "Message Sent", JOptionPane.INFORMATION_MESSAGE);
        } else {
            System.out.println("SKIPPER " + customer.getName());
        }
    }
}