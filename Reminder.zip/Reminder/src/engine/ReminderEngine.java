package engine;

import model.Purchase;
import notification.Notification;
import repository.ServiceRecordRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReminderEngine {

    private List<Purchase>     purchases = new ArrayList<>();
    private List<Notification> notifiers = new ArrayList<>();

    public void addPurchase(Purchase p)     { purchases.add(p); }
    public void addNotifier(Notification n) { notifiers.add(n); }

    public void checkAndNotify(int daysAhead) {
        ServiceRecordRepository serviceRepo = new ServiceRecordRepository();

        for (Purchase purchase : purchases) {
            try {
                // Load tanggal servis terakhir dari DB
                LocalDate lastService = serviceRepo.getLastServiceDate(purchase.getId());
                purchase.setLastServiceDate(lastService);

            } catch (Exception e) {
                System.out.println("[Engine] Gagal load service record: " + e.getMessage());
            }

            // Cek apakah due soon berdasarkan tanggal servis terakhir
            if (purchase.isDueSoon(daysAhead)) {
                for (Notification notifier : notifiers) {
                    notifier.send(
                        purchase.getCustomer(),
                        purchase.getProduct(),
                        purchase.getNextServiceDate()
                    );
                }
            }
        }
    }
}