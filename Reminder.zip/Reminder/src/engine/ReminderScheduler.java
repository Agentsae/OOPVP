package engine;

import notification.AdminAlertNotification;
import repository.PurchaseRepository;


import javax.swing.JOptionPane;



public class ReminderScheduler {

    public static void runNow() {
    try {
        System.out.println("[Scheduler] Manual check triggered...");
        PurchaseRepository repo = new PurchaseRepository();
        ReminderEngine engine   = new ReminderEngine();

        for (var purchase : repo.findAll()) {
            engine.addPurchase(purchase);
        }

        engine.addNotifier(new AdminAlertNotification());
        engine.checkAndNotify(7);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,
            "Error checking reminders: " + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}


}
